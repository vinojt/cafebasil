# No-Q
Help small business reduce wait times
